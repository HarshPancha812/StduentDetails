package com.example.demo.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("studentdetails")
public class StudentController {
	private StudentService studentService;

	public StudentController(com.example.demo.service.StudentService studentService) {
		super();
		this.studentService = studentService;
	}

	@PostMapping()
	public ResponseEntity<Student> saveStudent(@RequestBody Student student){
		return new ResponseEntity<Student>(studentService.saveStudent(student), HttpStatus.CREATED);
	}
	
	@GetMapping()
	public Page<Student> getAllStudent(@RequestParam("pageNo") int pageNo,@RequestParam("size") int pageSize){
		return studentService.getAllStudent(pageNo,pageSize);
	}
	
	@GetMapping("{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable("id") Long StudentId){
		return new ResponseEntity<Student>(studentService.getStudentById(StudentId),HttpStatus.OK);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable("id") Long studentId,@RequestBody Student student){
		return new ResponseEntity<Student>(studentService.updateStudent(studentId,student),HttpStatus.OK);
	}
	
	@DeleteMapping(value = "{id}")
	public ResponseEntity<?> deleteStudent(@PathVariable("id") Long studentId){
		studentService.deleteStudent(studentId);
		return new ResponseEntity(HttpStatus.OK);
	}
	
	@DeleteMapping("subject/{id}")
	public ResponseEntity<?> deleteSubject(@PathVariable("id") Long subjectId){
		studentService.deleteSubject(subjectId);
		return new ResponseEntity(HttpStatus.OK);
	}
}
