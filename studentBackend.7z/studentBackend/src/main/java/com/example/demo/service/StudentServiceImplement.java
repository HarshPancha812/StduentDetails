package com.example.demo.service;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Student;
import com.example.demo.model.Subject;
import com.example.demo.repository.StudentRepo;
import com.example.demo.repository.SubjectRepo;

@Service
public class StudentServiceImplement implements StudentService {

	@Autowired
	public StudentRepo studentRepo;
	
	@Autowired
	public SubjectRepo subjectRepo;
	
	@Override
	public Student saveStudent(Student student) {
		return studentRepo.save(student);
	}

	@Override
	public Page<Student> getAllStudent(int pageNo, int pageSize) {
	       return studentRepo.findAll(PageRequest.of(pageNo, pageSize));
	}

	@Override
	public Student getStudentById(Long id) {
		return studentRepo.findById(id).orElseThrow(()-> new ResourceNotFoundException("Student","id",id));
	}

	@Override
	public Student updateStudent(Long Id, Student student) {
		SubjectRepo subjectRepo;
		
		Student existingStudent = studentRepo.findById(Id).orElseThrow(()->
		new ResourceNotFoundException("Student","id",Id));
		
		existingStudent.setName(student.getName());
		existingStudent.setRollNo(student.getRollNo());
		existingStudent.setCountry(student.getCountry());
		existingStudent.setBirthDate(student.getBirthDate());
		existingStudent.setGender(student.getGender());
		existingStudent.setContactNo(student.getContactNo());
		existingStudent.setCurrentAddress(student.getCurrentAddress());
		existingStudent.setPermanentAddress(student.getPermanentAddress());
		existingStudent.setHobby(student.getHobby());
		existingStudent.setSubjects(student.getSubjects());
		
		
		studentRepo.save(existingStudent);
		return student;
	}

	@Override
	public void deleteStudent(Long Id) {
		studentRepo.findById(Id).orElseThrow(()->
		new ResourceNotFoundException("Student","id",Id));
		studentRepo.deleteById(Id);		
	}

	@Override
	public void deleteSubject(Long Id) {
		// TODO Auto-generated method stub
		subjectRepo.findById(Id).orElseThrow(()->
		new ResourceNotFoundException("subject","id",Id));
		subjectRepo.deleteById(Id);		
	}
	
}
