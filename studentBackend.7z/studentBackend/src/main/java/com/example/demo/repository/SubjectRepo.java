package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Student;
import com.example.demo.model.Subject;

public interface SubjectRepo extends JpaRepository<Subject, Long> {
	
}
