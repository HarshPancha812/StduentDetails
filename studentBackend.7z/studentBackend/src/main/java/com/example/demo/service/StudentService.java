package com.example.demo.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.example.demo.model.Student;

 public interface StudentService {
	 Student saveStudent(Student student);
	 Page<Student> getAllStudent(int pageNo,int pageSize);
	 Student getStudentById(Long id);
	 Student updateStudent(Long Id,Student student);
	 void deleteStudent(Long Id);
	 void deleteSubject(Long Id);
}
