package com.example.demo.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import lombok.Data;

@Data
@Entity
@Table(name = "Student")
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "Name")
	private String name;
	
	@Column(name = "RollNo")
	private Integer rollNo;
	
	@Column(name = "Country")
	private String country;
	
	@Column(name = "Birthdate")
	private Date birthDate;
	
	@Column(name = "Gender")
	private String gender;
	
	@Column(name = "ContactNo")
	private String contactNo;
	
	@Column(name = "currentAddress")
	private String currentAddress;
	
	@Column(name = "permanentAddress")
	private String permanentAddress;
	
	@Column(name = "Hobbies")
	private String hobby;
	
	@OneToMany(targetEntity = Subject.class,cascade = CascadeType.ALL)
	@JoinColumn(name="studentId",referencedColumnName = "id")
	private List<Subject> subjects;
	
}